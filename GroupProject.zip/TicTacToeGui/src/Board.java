public class Board {

	private char [][] board;


	public Board() {
		this.board = new char [3][3];
		
		int count = 1;
		for (int i=0; i<3; i++) {
			for (int j=0; j<3; j++) {
				String digitString = "" + count++;
				board[i][j] = digitString.charAt(0);
			}
		}
	}


	public boolean recordMove(int square, char symbol) {

		if (!isValidMove(square)) {
			return false;

		} else {
			int row = (square-1) / 3;
			int col = (square-1) % 3;

			board[row][col] = symbol;
			return true;
		}
	}


	private boolean isValidMove(int square) {

		if (square < 1 || square > 9) {
			return false;
		}

		int row = (square-1) / 3;
		int col = (square-1) % 3;

		return board[row][col] != 'X' && board[row][col] != 'O';
	}


	public char checkForWin() {
		
		int state = checkHorizontal() + checkVertical() + 
				checkDiagonalOne() + checkDiagonalTwo();
		
		// let's say that state must be either 0, 1 or 2 at this point
		assert(state > -1 && state < 3): "Error: state is " + state;
		
		if (state == 1) {
			return 'X';
		} else if (state == 2) {
			return 'O';
		}
		
		// if any square's value isn't X or O, the game isn't over
		for (int i=0; i<3; i++) {
			for (int j=0; j<3; j++) {
				if (board[i][j] != 'X' && board[i][j] != 'O') {
					return 'N';
				}
			}
		}
		
		return 'T';
	}


	// All these methods SHOULD work under the board class.
	private boolean checkforWin(int count) { //Takes an integer, in this case the number of Xs or Os in any Horizontal, Diagonal, or Vertical, and will return True if the total number is 3
		return count == 3;
	}

	
	private boolean checkforX(char x) { // Takes an integer, in this case, I use -1 and -2 to determine if the index value is an X or an O. Where as -1 = X and -2 = 0, should be able to just change these to chars.
		return x == 'X'; // will return TRUE if integer passed is -1.
	}

	
	private boolean checkforO(char o) { // Takes an integer.
		return o == 'O';
	}

	
	private int checkHorizontal() { //Checks Horizontal index values. Takes an integer 2d Array.
		int xcount = 0; //will count x
		int ocount = 0; //will count o
		int win = 0; //win condition variable, 1 = X Victory; 2 = Y Victory; 0 = Tie/No winner.

		for(int i = 0; i < this.board.length; i++) {
			for(int y = 0; y < board.length; y++) { // nested for loop to look through 2d array.
				if(checkforX(this.board[i][y])) { //calls checkforX function, on integer within that index value.
					xcount ++; //increments xcount by 1 if checkforX returns true;
				}
				if(checkforO(this.board[i][y])){ //calls check forO function on integer in index value.
					ocount ++; //increments ocount by 1 if checkforO returns true;
				}	
			}
			if(checkforWin(xcount)) { //checks if there are 3 occurrences of -1 (X)
				win = 1; //if checkforWin returns true win condition 1 means X won.
				break;
			}
			else if(checkforWin(ocount)) { //checks if there are 3 occurrences of -2 (O)
				win = 2; //if checkforWin returns true win condition 2 means O won.
				break;
			}
			else { //else there were no wins in that horizontal.
				ocount = 0; xcount = 0;
				win = 0;
			}
		}
		return win;
	}


	private int checkVertical() { //Checks Vertical index values. Takes an integer 2d Array.
		int xcount = 0; //will count x
		int ocount = 0; //will count o
		int win = 0; //win condition variable

		for(int i = 0; i < this.board.length; i++) {
			for(int y = 0; y < this.board.length; y++) { // nested for loop to look through 2d array.
				if(checkforX(this.board[y][i])) { //calls checkforX function, on integer within that index value.
					xcount ++; //increments xcount by 1 if checkforX returns true;
				}
				if(checkforO(this.board[y][i])){ //calls check forO function on integer in index value.
					ocount ++; //increments ocount by 1 if checkforO returns true;
				}
			}
			if(checkforWin(xcount)) { //checks if there are 3 occurrences of -1 (X)
				win = 1; //if checkforWin returns true win condition 1 means X won.
				break;
			}
			else if(checkforWin(ocount)) { //checks if there are 3 occurrences of -2 (O)
				win = 2; //if checkforWin returns true win condition 2 means O won.
				break;
			}
			else { //else there were no wins in that vertical.
				ocount = 0; xcount = 0;
				win = 0;
			}
		}
		return win;
	}


	private int checkDiagonalOne() { // same idea as methods above, except with diagonals. 

		int xcount = 0;
		int ocount = 0;
		int win = 0; 
		
		for(int i = 0 ; i < 3 ; i++) {
			if(checkforX(this.board[i][i])){ 
				xcount++;
			}
			if(checkforO(this.board[i][i])){
				ocount++;
			}
		}
		
		if(checkforWin(xcount)) {
			win = 1;
		}
		else if(checkforWin(ocount)) {
			win = 2;
		}
		else {
			win = 0;
		}
		return win;
	}	
	
	
	private int checkDiagonalTwo() {
		
		int xcount = 0;
		int ocount = 0;
		int win = 0;
		
		int d = 2;
		for(int r = 0; r < 3 ; r++){	
			if(checkforX(this.board[r][d])){
				xcount++;
			}
			if(checkforO(this.board[r][d])){
				ocount++;
			}
			d--;
		}
		
		if (checkforWin(xcount)) {
			win = 1;
		}
		else if (checkforWin(ocount)) {
			win = 2;
		}
		else {
			win = 0;
		}
		return win;
	}
	// Call anyone of these methods on the board, so long as the board has -1s or -2s to represent the X and Y placements.
	// To figure out who won, maybe write a loop until win > 0;


	//method to display the board
	//iterate through the board, printing each value, every three values will be broken up by a new line for formatting
	public void display() {
		for(int i = 0; i < board.length; i++) {
			for(int j = 0; j < board[i].length; j++) {
				System.out.print(board[i][j]);
			}
			System.out.println();
		}
	}


	//method to clear the board
	//iterates through the entire board and replaces all spaces with empty spaces
	public void clear() {
		char empty = ' ';
		for(int i = 0; i < board.length; i++) {
			for(int j = 0; j < board[i].length; j++) {
				board[i][j] = empty; 			
			}
		} 
	}
}











