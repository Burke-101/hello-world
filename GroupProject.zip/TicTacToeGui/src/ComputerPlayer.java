public class ComputerPlayer extends Player 
{

	private static final long serialVersionUID = 1L;


	ComputerPlayer(String name, char symbol)
	{
		super(name, symbol);
	}
	
	
	public void selectSquare(Board theBoard)
	{
		int square = (int)(Math.random() * 9) + 1;
		
		while (!theBoard.recordMove(square, super.getSymbol())) {
			 square = (int)(Math.random() * 9) + 1;
		}
		
		System.out.println(super.getName() + " moved to " + square);
	}
}


