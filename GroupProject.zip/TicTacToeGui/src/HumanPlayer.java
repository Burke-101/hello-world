//Jesse Liu, will mays, Corey Stamper, Anthony Morell, Ryan Ley, Yueqi Feng, Jared Cole, Zack Reichert

import java.util.Scanner;

public class HumanPlayer extends Player {
	
	private static final long serialVersionUID = 1L;

	public HumanPlayer(String name){
		super(name);
	}
	
	public HumanPlayer(String name, char symbol){
		super(name, symbol);
	}
	
	public void selectSquare(Board theBoard){
		
		Scanner input = new Scanner(System.in);
		System.out.print(super.getName() + ", enter move 1-9: ");
		int choice = input.nextInt();
		
		while(!theBoard.recordMove(choice, super.getSymbol())) {
			System.out.print("Re-enter a new number 1-9: ");
			choice = input.nextInt();
		}
	}
}
