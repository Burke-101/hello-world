import java.io.Serializable;

//Jesse Liu, will mays, Corey Stamper, Anthony Morell, Ryan Ley, Yueqi Feng, Jared Cole, Zack Reichert

public abstract class Player implements Comparable<Player>, Serializable {

	private static final long serialVersionUID = 1L;
	
	private String name;
	private int wins;
	private int losses;
	private int ties;
	private transient char symbol;
	
	protected Player() {
		this.name = "Player";
		this.wins = 0;
		this.losses = 0;
		this.ties = 0;
	}
	
	protected Player(String name) {
		this.name = name;
		this.wins = 0;
		this.losses = 0;
		this.ties = 0;
	}
	
	protected Player(String name, char symbol) {
		this.name = name;
		this.wins = 0;
		this.losses = 0;
		this.ties = 0;
		this.symbol = symbol;
	}
	
	public abstract void selectSquare(Board theBoard);
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public int getWins() {
		return wins;
	}
	
	public void setWins(int wins) {
		this.wins = wins;
	}
	
	public int getLosses() {
		return losses;
	}
	
	public void setLosses(int losses) {
		this.losses = losses;
	}
	
	public int getTies() {
		return ties;
	}
	
	public void setTies(int ties) {
		this.ties = ties;
	}
	
	public char getSymbol() {
		return symbol;
	}
	
	public void setSymbol(char symbol) {
		this.symbol = symbol;
	}
	
	public int compareTo(Player o) {
		if (this.getWins() > o.getWins()) {
			return -1;
		} else if (this.getWins() < o.getWins()) {
			return 1;
		} else if (this.getLosses() < o.getLosses()) {
			return -1;
		} else if (this.getLosses() > o.getLosses()) {
			return 1;
		} else if (this.getTies() > o.getTies()) {
			return -1;
		} else if (this.getTies() < o.getTies()) {
			return 1;
		} else {
			return this.getName().compareToIgnoreCase(o.getName());
		}
	}
	
	public String toString() {
		return name + "\t" + wins + "-" + losses + "-" + ties;
	}
}
