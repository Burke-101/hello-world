// Submitted by Andrew Griesdorn, Nicole Watzig, Jimmy Caupp, James Wright, and Jordan Bintz
/**
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.*;

import javafx.application.Application;
import javafx.beans.binding.Bindings;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
*/

/**
public class TicTacToe {


	private static Scanner input = new Scanner(System.in);


	@SuppressWarnings("unchecked")
	public static void main(String[] args) {

		
		Application.launch(args);
		
		
		// Before we start, read in all of the existing player accounts
		// from the data file
		ArrayList<Player> accounts = new ArrayList<>();
		
		File accountFile = new File("tictactoe.dat");
		if (accountFile.exists()) {
			try {
				ObjectInputStream ois = new ObjectInputStream(new FileInputStream(accountFile));
				accounts = (ArrayList<Player>) ois.readObject();
				ois.close();
			} catch (Exception e) {
				System.out.println("Could not read in existing account information -- " + 
						"continuing without it.");
			}
		}
		
		String name;
		char symbol = 0;	
		String compName[]= {"Bill", "Dave", "Jim", "Courtney", "Peggy", "Agatha"};
		String answer;

		Player player1 = null;
		Player player2 = null;

		boolean success = false;

		while (!success) {

			System.out.print("Is player one a human or a computer? ");
			answer = input.nextLine();

			if (answer.equalsIgnoreCase("human")){
				
				while (player1 == null) {
					
					System.out.print("What is your name? ");
					name = input.nextLine();

					player1 = getPlayer(accounts, name);

					if (player1 == null) {

						System.out.print("No account with that name exists. "
								+ "Would you like me to create one? ");
						answer = input.nextLine();

						if (answer.toLowerCase().startsWith("y")) {
							player1 = new HumanPlayer(name);
							accounts.add(player1);
						}
					}
				}
				
				player1.setSymbol(getSymbol());
				success = true;

			} else if(answer.equalsIgnoreCase("computer")) {
				name = "Computer " + compName[new Random().nextInt(compName.length)];
				System.out.println("The computer's name is " + name);
				symbol = getSymbol();
				player1 = new ComputerPlayer(name, symbol);
				success = true;

			} else {
				System.out.println("Sorry that was not a valid option.");
			}
		}

		answer = input.nextLine();
		success = false;

		while (!success) {
			
			System.out.print("Is the second player a human or a computer? ");
			answer = input.nextLine();

			if (answer.equalsIgnoreCase("human")){

				while (player2 == null) {

					System.out.print("What is your name? ");
					name = input.nextLine();

					player2 = getPlayer(accounts, name);

					if (player2 == null) {

						System.out.print("No account with that name exists. "
								+ "Would you like me to create one? ");
						answer = input.nextLine();

						if (answer.toLowerCase().startsWith("y")) {
							player2 = new HumanPlayer(name);
							accounts.add(player2);
						}
					}
				}
				
				symbol = 'X';
				if (player1.getSymbol() == 'X') {
					symbol = 'O';
				}
				
				player2.setSymbol(symbol);
				success = true;

			} else if(answer.equalsIgnoreCase("computer")) {

				Boolean different = false;
				String name2 = "";
				char symbol2 = 0 ;

				while (!different){

					name2 = compName[new Random().nextInt(compName.length)];
					if (name2.equalsIgnoreCase(player1.getName())){
						name2 = compName[new Random().nextInt(compName.length)];
					}
					else{
						name2 = "Computer " + name2;
						different = true;
					}
				}
				
				System.out.println("The computer's name is: " + name2);

				symbol2 = 'X';
				if (player1.getSymbol() == 'X') {
					symbol2 = 'O';
				}
				
				player2 = new ComputerPlayer(name2, symbol2);
				success = true;

			} else {
				System.out.println ("Sorry that was not a valid option.");
			}
		}

		System.out.println("Creating the board");

		Board theBoard = new Board();

		System.out.println("Determing random order for turns.");

		Random rand = new Random();

		int turn = rand.nextInt(2)+1;
		int player1even = 0;
		Boolean player1First = true;

		if (turn%2 != player1even){
			player1First = false;
		}

		Boolean gameEnded = false;
		char gameState = 'N';
		
		while(!gameEnded){
			
			if (player1First){
				
				theBoard.display();
				
				player1.selectSquare(theBoard);
				
				gameState = theBoard.checkForWin();
				if (gameState != 'N') {
					System.out.println(recordResults(player1, player2, gameState));
					break;
				}
				
				theBoard.display();
				
				player2.selectSquare(theBoard);
				
				gameState = theBoard.checkForWin();
				if (gameState != 'N') {
					System.out.println(recordResults(player1, player2, gameState));
					break;
				}

			} else {
				
				theBoard.display();
				
				player2.selectSquare(theBoard);
				
				gameState = theBoard.checkForWin();
				if (gameState != 'N') {
					System.out.println(recordResults(player1, player2, gameState));
					break;
				}
				
				theBoard.display();
				
				player1.selectSquare(theBoard);
				
				gameState = theBoard.checkForWin();
				if (gameState != 'N') {
					System.out.println(recordResults(player1, player2, gameState));
					break;
				}
			}

			gameEnded = theBoard.checkForWin() != 'N';
		}
		
		System.out.println("Here is the new Leaderboard:");
		Collections.sort(accounts);
		for (int i=0; i<Math.min(10, accounts.size()); i++) {
			System.out.println(accounts.get(i));
		}
		
		// Store the account information
		try {
			ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(accountFile));
			oos.writeObject(accounts);
			oos.close();
		} catch (Exception e) {
			System.out.println("Could not write the account information to disk");
		}
	}


	private static char getSymbol() {

		System.out.print("What should your symbol be? ");
		char symbol = input.next().toUpperCase().charAt(0);

		while (symbol != 'X' && symbol != 'O') {
			System.out.println("You must choose X or O.");
			System.out.print("What should your symbol be? ");
			symbol = input.next().toUpperCase().charAt(0);
		}

		return symbol;
	}
	
	
	
	
	private static String recordResults(Player p1, Player p2, char result) {
		
		if (result == p1.getSymbol()) {
			p1.setWins(p1.getWins()+1);
			p2.setLosses(p2.getLosses()+1);
			return p1.getName() + " won!";
			
		} else if (result == p2.getSymbol()) {
			p2.setWins(p2.getWins()+1);
			p1.setLosses(p1.getLosses()+1);
			return p2.getName() + " won!";
			
		} else {
			p1.setTies(p1.getTies() + 1);
			p2.setTies(p2.getTies() + 1);
			return "Tie!";
		}
	}
	
	
	private static Player getPlayer(ArrayList<Player> accounts, String name) {
		for (Player account: accounts) {
			if (account.getName().equalsIgnoreCase(name)) {
				return account;
			}
		}
		
		return null;
	}
}
*/